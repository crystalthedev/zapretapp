# ZapretApp Release Creator
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "   ZapretApp Release Creator" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""

# Stop all processes
Write-Host "[1/6] Stopping processes..." -ForegroundColor Yellow
Get-Process -Name "ZapretApp","winws" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2

# Clean
Write-Host "[2/6] Cleaning..." -ForegroundColor Yellow
Remove-Item "bin","obj" -Recurse -Force -ErrorAction SilentlyContinue

# Build
Write-Host "[3/6] Building..." -ForegroundColor Yellow
dotnet publish -c Release -r win-x64 --self-contained

if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed!" -ForegroundColor Red
    exit 1
}

$publishDir = "bin\Release\net8.0-windows\win-x64\publish"

# Single-file .exe only - all files embedded as resources
Write-Host "[4/6] Checking single-file..." -ForegroundColor Yellow

# Verify only ZapretApp.exe exists (or minimal files)
$exeFile = Get-Item "$publishDir\ZapretApp.exe" -ErrorAction SilentlyContinue
if (!$exeFile) {
    Write-Host "Error: ZapretApp.exe not found!" -ForegroundColor Red
    exit 1
}

Write-Host "[5/6] Cleaning extra files..." -ForegroundColor Yellow
# Remove all files except .exe and .pdb (for debugging)
Get-ChildItem "$publishDir" -File | Where-Object {$_.Name -ne "ZapretApp.exe" -and $_.Name -ne "ZapretApp.pdb"} | Remove-Item -Force -ErrorAction SilentlyContinue
Get-ChildItem "$publishDir" -Directory | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

# Create archive with only .exe file
Write-Host "[6/6] Creating archive..." -ForegroundColor Yellow
$version = "Beta"
$zipName = "ZapretApp-$version.zip"
Remove-Item $zipName -Force -ErrorAction SilentlyContinue

# Create archive with .exe and README.txt
$exePath = "$publishDir\ZapretApp.exe"
if (Test-Path $exePath) {
    # Create temp folder with files
    $tempDir = "$env:TEMP\ZapretAppRelease"
    Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    
    # Copy .exe
    Copy-Item $exePath -Destination "$tempDir\ZapretApp.exe" -Force
    
    # Copy README.txt if exists
    $readmeSrc = "..\USER_README.txt"
    if (Test-Path $readmeSrc) {
        Copy-Item $readmeSrc -Destination "$tempDir\README.txt" -Force
    }
    
    # Create zip
    Compress-Archive -Path "$tempDir\*" -DestinationPath $zipName -Force
    
    # Cleanup
    Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
} else {
    Write-Host "Error: ZapretApp.exe not found!" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "==================================" -ForegroundColor Green
Write-Host "   Release created successfully!" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green
Write-Host ""
Write-Host "Archive: $zipName" -ForegroundColor Cyan
Write-Host "Size: $((Get-Item $zipName).Length / 1MB | ForEach-Object {[math]::Round($_, 2)}) MB" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Test the archive" -ForegroundColor White
Write-Host "2. Create GitHub release" -ForegroundColor White
Write-Host "3. Upload $zipName" -ForegroundColor White
Write-Host ""
Write-Host "Note: Matryoshka folders removed!" -ForegroundColor Green
Write-Host ""


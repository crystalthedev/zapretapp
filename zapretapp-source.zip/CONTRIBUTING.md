# Contributing to ZapretApp

Thank you for your interest in contributing!

## Development Setup

1. Clone the repository
2. Install .NET 8.0 SDK
3. Copy required files to `project/bin/`:
   - `winws.exe`
   - `cygwin1.dll`
   - `WinDivert.dll`
   - `WinDivert64.sys`
4. Copy `lists/` folder to project root

## Building

```powershell
cd project
dotnet build -c Release
```

## Publishing

```powershell
cd project
dotnet publish -c Release -r win-x64
```

Output will be in `bin/Release/net8.0-windows/win-x64/publish/`

## Code Style

- Use tabs for indentation
- Keep comments minimal and in English
- Follow existing naming conventions

## Pull Requests

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Issues

Please report bugs and feature requests through GitHub Issues.


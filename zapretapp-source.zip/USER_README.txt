==============================================
   ZapretApp Beta
==============================================

DPI Bypass Tool with Beautiful UI

==============================================
  INSTALLATION / УСТАНОВКА
==============================================

1. Extract ZapretApp.exe to any folder
   Распакуйте ZapretApp.exe в любую папку

2. Run ZapretApp.exe AS ADMINISTRATOR
   Запустите ZapretApp.exe ОТ ИМЕНИ АДМИНИСТРАТОРА

   ⚠️ First run will:
   ⚠️ При первом запуске:
   - Show loading screen / Покажет экран загрузки
   - Create C:\zapretapp folder / Создаст папку C:\zapretapp
   - Extract necessary files / Извлечёт необходимые файлы
   - Open main window / Откроет главное окно

3. Click "Start" / "Запустить"

   ℹ️ All files are embedded in .exe
   ℹ️ Все файлы встроены в .exe

==============================================
  FEATURES / ВОЗМОЖНОСТИ
==============================================

✓ One-click bypass / Запуск в один клик
✓ Multi-language (EN/RU) / Русский/English
✓ Auto-start with Windows / Автозапуск
✓ Hide to tray / Скрытие в трей
✓ Halloween theme / Хэллоуин тема

==============================================
  SETTINGS / НАСТРОЙКИ
==============================================

Click "Settings" button to:
- Enable autostart / Включить автозапуск
- Hide on launch / Скрывать при запуске
- Change language / Изменить язык

==============================================
  REQUIREMENTS / ТРЕБОВАНИЯ
==============================================

- Windows 10/11
- Administrator rights / Права администратора

==============================================
  TROUBLESHOOTING / РЕШЕНИЕ ПРОБЛЕМ
==============================================

Q: Bypass not working?
A: Make sure you granted administrator rights

Q: Window doesn't appear?
A: Disable "Hide on launch" in Settings

Q: Обход не работает?
A: Убедитесь что дали права администратора

==============================================
  SUPPORT / ПОДДЕРЖКА
==============================================

Telegram: https://t.me/crystalthedev
GitHub: https://github.com/crystalthedev/zapretapp

==============================================
  LICENSE / ЛИЦЕНЗИЯ
==============================================

MIT License
© 2024 CrystalTheDev

Based on bol-van/zapret
https://github.com/bol-van/zapret

==============================================


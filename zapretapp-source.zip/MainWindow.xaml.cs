using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Threading;

namespace ZapretApp
{
	public partial class MainWindow : Window
	{
		private readonly string appDataDir = @"C:\zapretapp";
		private readonly string appDir = AppDomain.CurrentDomain.BaseDirectory;
		private string binDir => Path.Combine(appDataDir, "bin");
		private string listsDir => Path.Combine(appDataDir, "lists");
		private const string RegKey = "Software\\ZapretApp";
		private const string RegRunPath = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
		private const string AppName = "ZapretApp";
		private bool isEnglish = true;
		private DispatcherTimer statusTimer;

		public MainWindow()
		{
			InitializeComponent();
			LoadLanguage();
			LoadSettings();
			UpdateStatus();
			
			statusTimer = new DispatcherTimer();
			statusTimer.Interval = TimeSpan.FromSeconds(2);
			statusTimer.Tick += (s, e) => UpdateStatus();
			statusTimer.Start();
		}
		
		public void HandleAutoStart()
		{
			var args = Environment.GetCommandLineArgs();
			bool hiddenArg = args.Any(a => string.Equals(a, "--hidden", StringComparison.OrdinalIgnoreCase));
			if (hiddenArg && HideOnLaunchCheck.IsChecked == true)
			{
				_ = StartEngineAsync();
				Hide();
			}
		}

		private void Window_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.LeftButton == MouseButtonState.Pressed)
				DragMove();
		}

		private void Close_Click(object sender, RoutedEventArgs e) => Close();
		private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;


		private void LoadLanguage()
		{
			using var key = Registry.CurrentUser.CreateSubKey(RegKey);
			int lang = Convert.ToInt32(key.GetValue("Language", 1));
			isEnglish = lang == 1;
			UpdateLanguage();
		}

		private void SaveLanguage()
		{
			using var key = Registry.CurrentUser.CreateSubKey(RegKey);
			key.SetValue("Language", isEnglish ? 1 : 0, RegistryValueKind.DWord);
		}

		private void UpdateLanguage()
		{
			if (isEnglish)
			{
				AppSubtitle.Text = "DPI Bypass Tool";
				StatusLabel.Text = "Status:";
				StartButton.Content = "▶ Start";
				StopButton.Content = "■ Stop";
				SettingsButton.Content = "⚙ Settings";
				LanguageButton.Content = "🌐 EN";
				
				SettingsTitle.Text = "⚙️ Settings";
				SettingsSubtitle.Text = "Configure autostart and app behavior";
				LaunchParamsTitle.Text = "Launch Parameters";
				HideOnLaunchCheck.Content = "Hide window on application start";
				AutostartCheck.Content = "Autostart on Windows login";
				ActionsTitle.Text = "Actions";
				HideNowButton.Content = "Hide to tray";
				SaveButton.Content = "💾 Save";
				BackButton.Content = "← Back";
				FooterVersion.Text = "ZapretApp Beta";
			}
			else
			{
				AppSubtitle.Text = "Инструмент обхода DPI";
				StatusLabel.Text = "Статус:";
				StartButton.Content = "▶ Запустить";
				StopButton.Content = "■ Остановить";
				SettingsButton.Content = "⚙ Настройки";
				LanguageButton.Content = "🌐 RU";
				
				SettingsTitle.Text = "⚙️ Настройки";
				SettingsSubtitle.Text = "Настройте автозапуск и поведение приложения";
				LaunchParamsTitle.Text = "Параметры запуска";
				HideOnLaunchCheck.Content = "Скрывать окно при запуске приложения";
				AutostartCheck.Content = "Автоматический запуск при входе в Windows";
				ActionsTitle.Text = "Действия";
				HideNowButton.Content = "Скрыть в трей";
				SaveButton.Content = "💾 Сохранить";
				BackButton.Content = "← Назад";
				FooterVersion.Text = "ZapretApp Бета";
			}
			UpdateStatus();
		}

		private void LanguageButton_Click(object sender, RoutedEventArgs e)
		{
			isEnglish = !isEnglish;
			SaveLanguage();
			UpdateLanguage();
		}

		private void UpdateStatus()
		{
			var running = Process.GetProcessesByName("winws").Any();
			StatusText.Text = running ? (isEnglish ? "Running" : "Запущено") : (isEnglish ? "Stopped" : "Остановлено");
			StartButton.IsEnabled = !running;
			StopButton.IsEnabled = running;
			
			if (running)
			{
				StatusIndicator.Fill = (SolidColorBrush)FindResource("SuccessBrush");
				var effect = StatusIndicator.Effect as DropShadowEffect;
				if (effect != null)
					effect.Color = System.Windows.Media.Color.FromRgb(0x8B, 0xAA, 0x00);
			}
			else
			{
				StatusIndicator.Fill = (SolidColorBrush)FindResource("ErrorBrush");
				var effect = StatusIndicator.Effect as DropShadowEffect;
				if (effect != null)
					effect.Color = System.Windows.Media.Color.FromRgb(0xDC, 0x14, 0x3C);
			}
		}

		private void SettingsButton_Click(object sender, RoutedEventArgs e)
		{
			MainPage.Visibility = Visibility.Collapsed;
			SettingsPage.Visibility = Visibility.Visible;
		}

		private void BackButton_Click(object sender, RoutedEventArgs e)
		{
			SettingsPage.Visibility = Visibility.Collapsed;
			MainPage.Visibility = Visibility.Visible;
		}

		private void GitHubButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Process.Start(new ProcessStartInfo
				{
					FileName = "https://github.com/crystalthedev/zapretapp/tree/main",
					UseShellExecute = true
				});
			}
			catch { }
		}

		private void TelegramButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Process.Start(new ProcessStartInfo
				{
					FileName = "https://t.me/crystalthedev",
					UseShellExecute = true
				});
			}
			catch { }
		}

		private async void StartButton_Click(object sender, RoutedEventArgs e)
		{
			await StartEngineAsync();
		}

		public async void AutoStartBypass()
		{
			await StartEngineAsync();
		}

		private async Task StartEngineAsync()
		{
			try
			{
				// Use C:\zapretapp directory
				
				// Check game filter
				string gameFilterFile = Path.Combine(binDir, "game_filter.enabled");
				string gameFilter = File.Exists(gameFilterFile) ? "1024-65535" : "12";
				
				string winwsExe = Path.Combine(binDir, "winws.exe");
				string listGeneral = Path.Combine(listsDir, "list-general.txt");
				string ipsetAll = Path.Combine(listsDir, "ipset-all.txt");
				
				if (!File.Exists(winwsExe))
				{
					MessageBox.Show("winws.exe not found in C:\\zapretapp\\bin\\\nPlease reinstall the application.", "ZapretApp", MessageBoxButton.OK, MessageBoxImage.Error);
					return;
				}
				
				// ALT8 method without .bin files
				string args = $"--wf-tcp=80,443,2053,2083,2087,2096,8443,{gameFilter} --wf-udp=443,19294-19344,50000-50100,{gameFilter} " +
					$"--filter-udp=443 --hostlist=\"{listGeneral}\" --dpi-desync=fake --dpi-desync-repeats=6 --new " +
					$"--filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-repeats=6 --new " +
					$"--filter-tcp=80 --hostlist=\"{listGeneral}\" --dpi-desync=fake,split2 --dpi-desync-autottl=2 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --new " +
					$"--filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --new " +
					$"--filter-tcp=443 --hostlist=\"{listGeneral}\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --new " +
					$"--filter-udp=443 --ipset=\"{ipsetAll}\" --dpi-desync=fake --dpi-desync-repeats=6 --new " +
					$"--filter-tcp=80 --ipset=\"{ipsetAll}\" --dpi-desync=fake,split2 --dpi-desync-autottl=2 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --new " +
					$"--filter-tcp=443,{gameFilter} --ipset=\"{ipsetAll}\" --dpi-desync=syndata --new " +
					$"--filter-udp={gameFilter} --ipset=\"{ipsetAll}\" --dpi-desync=fake --dpi-desync-autottl=2 --dpi-desync-repeats=12 --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n2";
				
				// Start winws.exe hidden
				var psi = new ProcessStartInfo
				{
					FileName = winwsExe,
					Arguments = args,
					UseShellExecute = true,
					Verb = "runas",
					WorkingDirectory = binDir,
					CreateNoWindow = true,
					WindowStyle = ProcessWindowStyle.Hidden
				};
				
				try
				{
					Process.Start(psi);
					
					// Wait and check
					for (int i = 0; i < 10; i++)
					{
						await Task.Delay(1000);
						UpdateStatus();
						
						if (Process.GetProcessesByName("winws").Any())
							break;
					}
					
					UpdateStatus();
				}
				catch (System.ComponentModel.Win32Exception)
				{
					string msg = isEnglish ? 
						"Administrator rights required.\n\nPlease click 'Yes' in the UAC dialog." :
						"Требуются права администратора.\n\nНажмите 'Да' в диалоге UAC.";
					MessageBox.Show(msg, "ZapretApp", MessageBoxButton.OK, MessageBoxImage.Warning);
					return;
				}
				catch (Exception ex)
				{
					string msg = isEnglish ? 
						$"Start error:\n{ex.Message}" :
						$"Ошибка запуска:\n{ex.Message}";
					MessageBox.Show(msg, "ZapretApp", MessageBoxButton.OK, MessageBoxImage.Error);
					return;
				}
			}
			catch (Exception ex)
			{
				string msg = isEnglish ? 
					$"Start error:\n{ex.Message}\n\nMake sure bin\\ and lists\\ folders are next to the application." :
					$"Ошибка запуска:\n{ex.Message}\n\nПроверьте что папки bin\\ и lists\\ находятся рядом с приложением.";
				MessageBox.Show(msg, "ZapretApp", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private async void StopButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				// Kill all winws.exe processes
				foreach (var p in Process.GetProcessesByName("winws"))
				{
					try
					{
						p.Kill();
						p.WaitForExit(3000);
					}
					catch { }
				}

				// Also kill any cmd.exe that might be hanging
				var cmdProcesses = Process.GetProcessesByName("cmd");
				foreach (var cmd in cmdProcesses)
				{
					try
					{
						// Only kill cmd if it's related to winws
						if (cmd.MainWindowTitle.Contains("winws") || cmd.MainWindowTitle.Contains("zapret"))
						{
							cmd.Kill();
							cmd.WaitForExit(1000);
						}
					}
					catch { }
				}

				await Task.Delay(500);
				UpdateStatus();
			}
			catch (Exception ex)
			{
				string msg = isEnglish ? 
					$"Stop error: {ex.Message}" :
					$"Ошибка остановки: {ex.Message}";
				MessageBox.Show(msg, "ZapretApp", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void SaveSettings_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				using var key = Registry.CurrentUser.CreateSubKey(RegKey);
				key.SetValue("HideOnLaunch", HideOnLaunchCheck.IsChecked == true ? 1 : 0, RegistryValueKind.DWord);
				key.SetValue("Autostart", AutostartCheck.IsChecked == true ? 1 : 0, RegistryValueKind.DWord);
				ApplyAutostart(AutostartCheck.IsChecked == true);
				MessageBox.Show("Настройки сохранены!", "ZapretApp", MessageBoxButton.OK, MessageBoxImage.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "ZapretApp", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void LoadSettings()
		{
			using var key = Registry.CurrentUser.CreateSubKey(RegKey);
			int hide = Convert.ToInt32(key.GetValue("HideOnLaunch", 0));
			int auto = Convert.ToInt32(key.GetValue("Autostart", 0));
			HideOnLaunchCheck.IsChecked = hide == 1;
			AutostartCheck.IsChecked = auto == 1;
		}

		private void ApplyAutostart(bool enable)
		{
			string exe = Process.GetCurrentProcess().MainModule!.FileName!;
			using var run = Registry.CurrentUser.CreateSubKey(RegRunPath);
			if (enable)
				run.SetValue(AppName, '"' + exe + '"' + " --hidden");
			else
				run.DeleteValue(AppName, false);
		}

		private void HideNow_Click(object sender, RoutedEventArgs e)
		{
			Hide();
		}
	}
}

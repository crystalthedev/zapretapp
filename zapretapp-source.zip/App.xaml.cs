using System.IO;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;

namespace ZapretApp
{
	public partial class App : Application
	{
		protected override async void OnStartup(StartupEventArgs e)
		{
			base.OnStartup(e);

			bool isAutostart = e.Args.Length > 0 && e.Args[0] == "--hidden";

			// Check if files already exist
			string appDataDir = @"C:\zapretapp";
			string binDir = System.IO.Path.Combine(appDataDir, "bin");
			string winwsExe = System.IO.Path.Combine(binDir, "winws.exe");
			bool needsExtraction = !System.IO.File.Exists(winwsExe);

			// Show splash only if files need to be extracted
			SplashWindow? splashWindow = null;
			if (needsExtraction)
			{
				splashWindow = new SplashWindow();
				splashWindow.Show();
				splashWindow.Activate();
				
				// Initialize app data (extract resources)
				bool success = await splashWindow.InitializeAppDataAsync();
				splashWindow.Close();
				
				if (!success)
				{
					Shutdown();
					return;
				}
			}

			// Show main window
			var mainWindow = new MainWindow();
			MainWindow = mainWindow;
			mainWindow.Show();
			mainWindow.Activate();
			
			// Process autostart
			if (isAutostart)
			{
				using (var key = Registry.CurrentUser.OpenSubKey(@"Software\ZapretApp"))
				{
					if (key != null)
					{
						var hideOnLaunch = key.GetValue("HideOnLaunch");
						if (hideOnLaunch != null && hideOnLaunch.ToString() == "1")
						{
							mainWindow.WindowState = WindowState.Minimized;
							mainWindow.Hide();
						}
					}
				}

				mainWindow.AutoStartBypass();
			}
		}
	}
}

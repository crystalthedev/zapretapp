using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Animation;

namespace ZapretApp
{
	public partial class SplashWindow : Window
	{
		private readonly string appDataDir = @"C:\zapretapp";
		private string binDir => Path.Combine(appDataDir, "bin");
		private string listsDir => Path.Combine(appDataDir, "lists");
		
		public SplashWindow()
		{
			InitializeComponent();
		}
		
		public async Task<bool> InitializeAppDataAsync()
		{
			await Task.Delay(300); // Small delay for UI to appear
			
			try
			{
				// Create directories first (always)
				if (!Directory.Exists(appDataDir))
				{
					UpdateStatus("Creating directories...", 0.1);
					await Task.Delay(200);
					Directory.CreateDirectory(appDataDir);
					Directory.CreateDirectory(binDir);
					Directory.CreateDirectory(listsDir);
				}
				
				// Check if already initialized
				string winwsExe = Path.Combine(binDir, "winws.exe");
				bool needsExtraction = !File.Exists(winwsExe);
				
				if (needsExtraction)
				{
					
					// Extract embedded resources
					UpdateStatus("Extracting winws.exe...", 0.2);
					await ExtractResourceAsync("Resources.winws.exe", Path.Combine(binDir, "winws.exe"));
					
					UpdateStatus("Extracting DLL files...", 0.4);
					await ExtractResourceAsync("Resources.cygwin1.dll", Path.Combine(binDir, "cygwin1.dll"));
					await ExtractResourceAsync("Resources.WinDivert.dll", Path.Combine(binDir, "WinDivert.dll"));
					await ExtractResourceAsync("Resources.WinDivert64.sys", Path.Combine(binDir, "WinDivert64.sys"));
					
					UpdateStatus("Extracting lists...", 0.7);
					await ExtractResourceAsync("Resources.ipset-all.txt", Path.Combine(listsDir, "ipset-all.txt"));
					await ExtractResourceAsync("Resources.list-general.txt", Path.Combine(listsDir, "list-general.txt"));
					
					UpdateStatus("Complete!", 1.0);
					await Task.Delay(300);
				}
				else
				{
					// Already initialized - quick skip
					UpdateStatus("Ready!", 1.0);
					await Task.Delay(200);
				}
				
				return true;
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error initializing: {ex.Message}\n\nPlease ensure you have administrator rights.", 
					"ZapretApp", MessageBoxButton.OK, MessageBoxImage.Error);
				return false;
			}
		}
		
		private async Task ExtractResourceAsync(string resourceName, string outputPath)
		{
			await Task.Run(() =>
			{
				try
				{
					var assembly = Assembly.GetExecutingAssembly();
					using var stream = assembly.GetManifestResourceStream(resourceName);
					if (stream == null)
						throw new FileNotFoundException($"Resource not found: {resourceName}");
					
					using var fileStream = new FileStream(outputPath, FileMode.Create);
					stream.CopyTo(fileStream);
				}
				catch (Exception ex)
				{
					throw new Exception($"Failed to extract {resourceName}: {ex.Message}", ex);
				}
			});
		}
		
		private void UpdateStatus(string text, double progress)
		{
			Dispatcher.Invoke(() =>
			{
				StatusText.Text = text;
				ProgressBar.Width = 400 * progress;
			});
		}
	}
}

